const toggle = document.getElementById('chatToggle');
const badge = document.getElementById('badge');

function updateUI(isChatVisible) {
  toggle.checked = isChatVisible;
  if (isChatVisible) {
    badge.textContent = 'ON';
    badge.className = 'badge';
  } else {
    badge.textContent = 'MASQUÉ';
    badge.className = 'badge off';
  }
}

// 1. Charger l'état actuel (par défaut : visible = true)
chrome.storage.local.get({ showChat: true }, (res) => {
  updateUI(res.showChat);
});

// 2. Écouter le basculement du switch
toggle.addEventListener('change', () => {
  const isChatVisible = toggle.checked;
  updateUI(isChatVisible);
  chrome.storage.local.set({ showChat: isChatVisible });
});