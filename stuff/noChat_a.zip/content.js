// 1. Injection des styles unifiés
const style = document.createElement('style');
style.id = 'yt-chat-toggle-styles';
style.textContent = `
  /* Masquer le chat sans détruire l'iframe (conserve le flux live actif) */
  html.yt-hide-live-chat ytd-live-chat-frame#chat {
    width: 0px !important;
    min-width: 0px !important;
    max-width: 0px !important;
    height: 0px !important;
    min-height: 0px !important;
    opacity: 0 !important;
    visibility: hidden !important;
    pointer-events: none !important;
    margin: 0 !important;
    padding: 0 !important;
    border: none !important;
  }

  /* MODE CINÉMA : neutraliser le conteneur du panneau latéral pour combler la bande noire */
  html.yt-hide-live-chat #panels-full-bleed-container {
    width: 0px !important;
    min-width: 0px !important;
    max-width: 0px !important;
    flex: 0 0 0px !important;
    margin: 0 !important;
    padding: 0 !important;
  }

  /* MODE CINÉMA : forcer le conteneur du lecteur vidéo à occuper 100% de l'espace */
  html.yt-hide-live-chat #player-full-bleed-container {
    width: 100% !important;
    max-width: 100% !important;
    flex: 1 1 100% !important;
  }
`;
(document.head || document.documentElement).appendChild(style);

// 2. Gestion de l'état (Toggle)
function applyState(showChat) {
  if (showChat) {
    document.documentElement.classList.remove('yt-hide-live-chat');
  } else {
    document.documentElement.classList.add('yt-hide-live-chat');
  }

  // Notifier YouTube du changement de dimensions pour adapter le lecteur
  window.dispatchEvent(new Event('resize'));
  setTimeout(() => {
    window.dispatchEvent(new Event('resize'));
  }, 100);
}

// 3. Initialisation au chargement de la page
chrome.storage.local.get({ showChat: true }, (res) => {
  applyState(res.showChat);
});

// 4. Écoute dynamique du toggle depuis la popup
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.showChat !== undefined) {
    applyState(changes.showChat.newValue);
  }
});