// 
// jdDelaunay.js (Cleaned, Optimized, Movable Sites, Magnetism & Exact Pixel-to-Pixel Gradients v1.5.8)
// Created by BriceMG ( insta:BriceMG)
// Inspired by Dan Borufka and Jake Rathmanner
// Updated: Custom gradients now sample exact pixel colors at Press and Release points with precise vector orientation.

// ==========================================
// 0. APPLICATION STATE (Namespaced)
// ==========================================
var DIT = {
    brush: null,
    sites: [],
    raster: null,
    shape: null,
    firstRun: true,
    xray: true,
    solid: true,
    magnetism: 8,
    dragThreshold: 2,
    group_main: null,
    group_sites: null,
    group_tris: null,
    activeSite: null,
    activeGradientTriangle: null,
    gradientStartPoint: null,
    hasDragged: false,
    customGradients: {},
    def_color: new CMYKColor(0, 0.74, 1, 0)
};

// Timer utility function
function codeTimer() {
    var start = new Date().valueOf();
    this.elapsed = function() {
        return new Date().valueOf() - start;
    };
}

if (document == null) {
    Dialog.alert("Please open up a document first.");
} else {
    
    // ==========================================
    // 1. TRIANGLE CLASS & GEOMETRY
    // ==========================================
    function Triangle(j, i, h) {
        this.a = j;
        this.b = i;
        this.c = h;
        var g = i.x - j.x,
            f = i.y - j.y,
            e = h.x - j.x,
            d = h.y - j.y,
            q = g * (j.x + i.x) + f * (j.y + i.y),
            o = e * (j.x + h.x) + d * (j.y + h.y),
            m = 2 * (g * (h.y - i.y) - f * (h.x - i.x)),
            l, k, p, n;
        
        if (Math.abs(m) < 0.000001) {
            var l = Math.min(j.x, i.x, h.x),
                k = Math.min(j.y, i.y, h.y),
                p = (Math.max(j.x, i.x, h.x) - l) * 0.5,
                n = (Math.max(j.y, i.y, h.y) - k) * 0.5;
            this.x = l + p;
            this.y = k + n;
            this.r = p * p + n * n;
        } else {
            this.x = (d * q - f * o) / m;
            this.y = (g * o - e * q) / m;
            var p = this.x - j.x,
                n = this.y - j.y;
            this.r = p * p + n * n;
        }
    }
    
    Triangle.prototype.draw = function(a) {};

    function byX(d, c) {
        return c.x - d.x;
    }

    function unique(f) {
        var g = f.length, e, d, h, c, k;
        outer: while (g) {
            d = f[--g];
            e = f[--g];
            h = g;
            while (h) {
                k = f[--h];
                c = f[--h];
                if ((e === c && d === k) || (e === k && d === c)) {
                    f.splice(g, 2);
                    f.splice(h, 2);
                    g -= 2;
                    continue outer;
                }
            }
        }
    }

    // ==========================================
    // 2. DELAUNAY TRIANGULATION ALGORITHM
    // ==========================================
    function triangulate(o) {
        if (o.length < 3) {
            return [];
        }
        o.sort(byX);
        var h = o.length - 1,
            c = o[h].x,
            k = o[0].x,
            s = o[h].y,
            d = s;
        
        while (h--) {
            if (o[h].y < s) { s = o[h].y; }
            if (o[h].y > d) { d = o[h].y; }
        }
        
        var u = k - c,
            t = d - s,
            p = (u > t) ? u : t,
            m = (k + c) * 0.5,
            e = (d + s) * 0.5,
            l = [new Triangle({ x: m - 20 * p, y: e - p, __sentinel: true }, { x: m, y: e + 20 * p, __sentinel: true }, { x: m + 20 * p, y: e - p, __sentinel: true })],
            n = [],
            g = [],
            f, r, q;
        
        h = o.length;
        while (h--) {
            g.length = 0;
            f = l.length;
            while (f--) {
                u = o[h].x - l[f].x;
                if (u > 0 && u * u > l[f].r) {
                    n.push(l[f]);
                    l.splice(f, 1);
                    continue;
                }
                t = o[h].y - l[f].y;
                if (u * u + t * t > l[f].r) {
                    continue;
                }
                g.push(l[f].a, l[f].b, l[f].b, l[f].c, l[f].c, l[f].a);
                l.splice(f, 1);
            }
            unique(g);
            f = g.length;
            while (f) {
                q = g[--f];
                r = g[--f];
                l.push(new Triangle(r, q, o[h]));
            }
        }
        Array.prototype.push.apply(n, l);
        h = n.length;
        while (h--) {
            if (n[h].a.__sentinel || n[h].b.__sentinel || n[h].c.__sentinel) {
                n.splice(h, 1);
            }
        }
        return n;
    }

    // ==========================================
    // 3. OPTIMIZED DRAWING & COLOR SAMPLING
    // ==========================================
    function applyCustomGradientToTriangle(tri, startPoint, endPoint) {
        // Échantillonnage précis des pixels aux points exacts de Press (start) et Release (end)
        var sampleSize = 2; // Petit carré autour du pixel pour lisser légèrement si besoin
        var areaStart = Path.Rectangle(new Point(startPoint.x - sampleSize, startPoint.y - sampleSize), new Size(sampleSize * 2, sampleSize * 2));
        var areaEnd = Path.Rectangle(new Point(endPoint.x - sampleSize, endPoint.y - sampleSize), new Size(sampleSize * 2, sampleSize * 2));

        var colorStart = DIT.raster.getAverageColor(areaStart);
        var colorEnd = DIT.raster.getAverageColor(areaEnd);

        areaStart.remove();
        areaEnd.remove();

        if (colorStart == null) { colorStart = DIT.def_color; }
        if (colorEnd == null) { colorEnd = DIT.def_color; }

        var grad = new Gradient({
            type: "linear",
            stops: new Array(new GradientStop(colorStart, 0), new GradientStop(colorEnd, 1))
        });
        
        // Application du dégradé orienté précisément du point de départ vers le point d'arrivée
        tri.fillColor = new GradientColor(grad, startPoint, endPoint);
    }

    function applyDefaultGradientToTriangle(tri, u) {
        var scaleFactor = 0.66;
        var pPos = new Point(u.a.x, u.a.y);
        var midPos = new Point(u.b.x + (u.c.x - u.b.x) / 2, u.b.y + (u.c.y - u.b.y) / 2);

        var g = tri.clone(),
            f = tri.clone();
        g.scale(scaleFactor, scaleFactor, pPos);
        f.scale(scaleFactor, scaleFactor, midPos);
        
        var z = DIT.raster.getAverageColor(g);
        var bCol = DIT.raster.getAverageColor(f);
        
        if (z == null) { z = DIT.def_color; }
        if (bCol == null) { bCol = DIT.def_color; }
        
        g.remove();
        f.remove();
        
        var grad = new Gradient({
            type: "linear",
            stops: new Array(new GradientStop(z, 0), new GradientStop(bCol, 1))
        });
        tri.fillColor = new GradientColor(grad, pPos, midPos);
    }

    function drawTriangulation(x) {
        var timer = new codeTimer(),
            w = [];
        
        if (DIT.group_tris) {
            DIT.group_tris.remove();
        }
        DIT.group_tris = new Group();
        DIT.group_tris.name = "D.I. triangles";
        DIT.group_tris.opacity = DIT.xray ? 0.5 : 1;
        if (DIT.group_main) {
            DIT.group_main.appendTop(DIT.group_tris);
        }

        for (var y = 0, t = 0, s = x.length; y < s; y++) {
            if (x[y].isValid() && x[y].length != 0) {
                for (var r = 0, q = x[y].segments.length; r < q; r++) {
                    w[t++] = x[y].segments[r].point;
                }
            } else {
                if (x[y].isValid()) {
                    w[t++] = x[y].position;
                }
            }
        }
        
        DIT.group_tris.locked = false;
        var h = triangulate(w);
        
        for (var v in h) {
            var u = h[v];
            var c = new Path();
            c.name = "triangle_" + v;
            DIT.group_tris.appendTop(c);
            
            c.segments = [
                new Segment(u.a.x, u.a.y),
                new Segment(u.b.x, u.b.y),
                new Segment(u.c.x, u.c.y)
            ];
            c.closed = true;
            
            if (DIT.raster) {
                if (DIT.solid) {
                    var fillColor = DIT.raster.getAverageColor(c);
                    if (fillColor == null) { fillColor = DIT.def_color; }
                    c.fillColor = fillColor;
                } else {
                    if (DIT.customGradients[c.name]) {
                        var custom = DIT.customGradients[c.name];
                        applyCustomGradientToTriangle(c, custom.start, custom.end);
                    } else {
                        applyDefaultGradientToTriangle(c, u);
                    }
                }
            } else {
                c.fillColor = DIT.def_color;
            }
        }
        DIT.group_tris.locked = true;
    }

    // ==========================================
    // 4. UTILITIES & SELECTION MANAGEMENT
    // ==========================================
    function useImage(b) {
        var a = document.getItems({ type: Raster, selected: true });
        if (a.length == 0) {
            if (document.selectedItems.length == 0) {
                Dialog.alert("You have to select a rasterized image first.");
                return;
            } else {
                if (!b) {
                    if (Dialog.confirm("Rasterizing", "Your selection is either not an embedded image or not rasterized. Would you like to rasterize it now?")) {
                        a[0] = document.selectedItems[0].rasterize("cmyk", 72, 4);
                    } else {
                        return;
                    }
                }
            }
        } else {
            DIT.raster = a[0];
            Dialog.alert("Image " + DIT.raster.name + " is now selected as sampling object.");
        }
    }

    function fillShape() {
        var b = document.getItems({ type: Path, selected: true });
        if (b.length == 0) {
            Dialog.alert("You have to select a path first.");
            return;
        } else {
            DIT.shape = b[0];
        }
        
        var d = Dialog.prompt("Number of sites", {
            siteNum: { description: "please specify a number of sites" }
        }, { siteNum: 100 });
        
        if (!d) { return; }
        if (d.siteNum < 3) {
            Dialog.alert("The number must be larger than 2.");
            fillShape();
        }
        
        var e, g = new Point(DIT.shape.bounds.left, DIT.shape.bounds.top),
            f = new Point(DIT.shape.bounds.width, DIT.shape.bounds.height);
        
        while (DIT.sites.length < d.siteNum) {
            e = g + Point.random() * f;
            if (DIT.shape.contains(e)) {
                onMouseDown({ point: e, type: "programmatic" });
                onMouseUp({ point: e, type: "programmatic" });
            }
        }
        
        for (var c = 0, a = DIT.shape.segments.length; c < a; c++) {
            onMouseDown({ point: DIT.shape.segments[c].point, type: "programmatic" });
            onMouseUp({ point: DIT.shape.segments[c].point, type: "programmatic" });
        }
        
        drawTriangulation(DIT.sites);
        DIT.shape.added = true;
    }

    function reset() {
        DIT.sites = [];
        DIT.firstRun = true;
        DIT.raster = DIT.shape = DIT.group_main = DIT.group_sites = DIT.group_tris = null;
        DIT.activeSite = null;
        DIT.activeGradientTriangle = null;
        DIT.customGradients = {};
    }

    function remove(c) {
        for (var b = 0, a = c.length; b < a; b++) {
            if (c[b].length != 0) {
                remove(c[b].segments);
            } else {
                DIT.sites.splice(c[b].index, 1);
                c[b].remove();
            }
        }
        DIT.customGradients = {};
        if (DIT.sites.length > 2) {
            drawTriangulation(DIT.sites);
        } else {
            if (DIT.group_tris) { DIT.group_tris.remove(); }
        }
    }

    function xrayMode() {
        DIT.xray = !DIT.xray;
        if (DIT.group_tris) {
            DIT.group_tris.opacity = DIT.xray ? 0.5 : 1;
        }
    }

    function solidMode() {
        DIT.solid = !DIT.solid;
        if (DIT.sites.length > 2) {
            drawTriangulation(DIT.sites);
        }
    }

    // ==========================================
    // 5. MOUSE EVENT HANDLERS
    // ==========================================
    function onMouseMove(event) {
        var nearSite = false;
        for (var i = 0; i < DIT.sites.length; i++) {
            if (DIT.sites[i].position.getDistance(event.point) < DIT.magnetism) {
                nearSite = true;
                break;
            }
        }

        if (nearSite) {
            if (!DIT.brush) {
                DIT.brush = new Path.Circle(event.point, 5);
                DIT.brush.strokeColor = new CMYKColor(0, 1, 1, 0);
                DIT.brush.fillColor = null;
            } else {
                DIT.brush.position = event.point;
                DIT.brush.strokeColor = new CMYKColor(0, 1, 1, 0);
            }
        } else {
            if (!DIT.activeGradientTriangle && !DIT.activeSite) {
                if (DIT.brush) {
                    DIT.brush.remove();
                    DIT.brush = null;
                }
            }
        }
    }

    function onMouseDown(event) {
        if (DIT.firstRun) {
            DIT.group_main = new Group();
            DIT.group_main.name = "Delaunay Image Triangulation";
            DIT.group_sites = new Group();
            DIT.group_sites.name = "D.I.T. sites";
            document.activeLayer.appendTop(DIT.group_main);
            DIT.group_main.appendTop(DIT.group_sites);
            DIT.firstRun = false;
        }

        DIT.hasDragged = false;

        // 1. Vérifier si on touche un site pour le déplacer
        DIT.activeSite = null;
        for (var i = 0; i < DIT.sites.length; i++) {
            if (DIT.sites[i].position.getDistance(event.point) < DIT.magnetism) {
                DIT.activeSite = DIT.sites[i];
                return;
            }
        }

        // 2. Si on est en mode Dégradé, préparer un éventuel drag de gradient
        DIT.activeGradientTriangle = null;
        if (!DIT.solid && DIT.raster && DIT.group_tris) {
            var children = DIT.group_tris.children;
            for (var j = 0; j < children.length; j++) {
                if (children[j].contains(event.point)) {
                    DIT.activeGradientTriangle = children[j];
                    DIT.gradientStartPoint = event.point;
                    break;
                }
            }
        }
    }

    function onMouseDrag(event) {
        if (DIT.activeSite) {
            DIT.activeSite.position = event.point;
            if (DIT.brush) { DIT.brush.position = event.point; }
        } else if (DIT.activeGradientTriangle && DIT.gradientStartPoint) {
            if (DIT.gradientStartPoint.getDistance(event.point) > DIT.dragThreshold) {
                DIT.hasDragged = true;
                if (DIT.brush) { DIT.brush.remove(); }
                DIT.brush = new Path.Line(DIT.gradientStartPoint, event.point);
                DIT.brush.strokeColor = new CMYKColor(0, 0, 0, 100);
            }
        } else {
            if (DIT.brush) { DIT.brush.remove(); }
            DIT.brush = new Path.Circle(event.point, 2);
        }
    }

    function onMouseUp(event) {
        if (DIT.brush) {
            DIT.brush.remove();
            DIT.brush = null;
        }

        if (DIT.activeSite) {
            DIT.activeSite = null;
            if (DIT.sites.length > 2) {
                drawTriangulation(DIT.sites);
            }
        } else if (DIT.activeGradientTriangle) {
            if (DIT.hasDragged) {
                // S'il y a eu un drag : Appliquer le gradient personnalisé basé sur les pixels exacts Press -> Release
                var triName = DIT.activeGradientTriangle.name;
                DIT.customGradients[triName] = {
                    start: DIT.gradientStartPoint,
                    end: event.point
                };
                applyCustomGradientToTriangle(DIT.activeGradientTriangle, DIT.gradientStartPoint, event.point);
            } else {
                // Simple clic : Créer un point 'site'
                var a = new Path();
                a.add(new Point(event.point));
                a.name = "site_" + DIT.sites.length;
                a.jdType = "site";
                DIT.sites.push(a);
                DIT.group_sites.appendBottom(a);
                
                if (DIT.sites.length > 2) {
                    drawTriangulation(DIT.sites);
                }
            }
            DIT.activeGradientTriangle = null;
            DIT.gradientStartPoint = null;
            DIT.hasDragged = false;
        } else {
            var a = new Path();
            a.add(new Point(event.point));
            a.name = "site_" + DIT.sites.length;
            a.jdType = "site";
            DIT.sites.push(a);
            DIT.group_sites.appendBottom(a);
            
            if (DIT.sites.length > 2) {
                drawTriangulation(DIT.sites);
            }
        }
    }

    // ==========================================
    // 6. UI PALETTE & INITIALIZATION
    // ==========================================
    var components = {
        ruler0: { label: "Generation Options", type: "ruler" },
        useBtn: { type: "button", value: "use selected image", onClick: useImage },
        magnetism: { 
            type: "number", 
            label: "Magnetism", 
            value: 8, 
            units: "pixel", 
            range: [1, 50], 
            steppers: true, 
            onChange: function(value) {
                DIT.magnetism = value;
            } 
        },
        xray: { label: "x-ray mode", onChange: xrayMode },
        solid: { label: "solid colors", onChange: solidMode },
        resetBtn: { type: "button", value: "reset tool", onClick: reset },
        fillBtn: { type: "button", value: "fill selected shape with random sites", onClick: fillShape },
        delBtn: {
            type: "button",
            value: "remove selected site(s)",
            onClick: function() {
                remove(document.getItems({ type: [Point, Path], selected: true }));
            }
        }
    };

    if (document.selectedItems.length > 0) {
        useImage(true);
    }

    var palette = new Palette("Delaunay Image Triangulation", components, { xray: DIT.xray, solid: DIT.solid, magnetism: DIT.magnetism });
}