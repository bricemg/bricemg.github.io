// content.js — Inspects the DOM to retrieve exact coordinates or knowledge panel addresses

(() => {
  function scanPageForLocation() {
    // 1. GPS coordinates extraction
    const geoEl = document.querySelector('[data-latlng]');
    if (geoEl) {
      const latlng = geoEl.getAttribute('data-latlng');
      if (latlng) return { detected: true, target: latlng };
    }

    // 2. Knowledge Graph panel address
    const addressEl = document.querySelector('[data-attrid*="address"] span, [data-attrid*="location"] span');
    if (addressEl && addressEl.textContent.trim()) {
      return { detected: true, target: addressEl.textContent.trim() };
    }

    // 3. Local place or directions card
    const mapOrDirectionEl = document.querySelector('a[href*="/maps/dir/"], a[href*="/maps/place/"], div[id*="lu_map"]');
    if (mapOrDirectionEl) {
      const titleEl = document.querySelector('h2[data-attrid="title"], [data-attrid="title"] span');
      return {
        detected: true,
        target: titleEl ? titleEl.textContent.trim() : null
      };
    }

    return { detected: false, target: null };
  }

  function notifyBackground() {
    const result = scanPageForLocation();
    if (result.detected) {
      chrome.runtime.sendMessage({
        type: "PAGE_ANALYSIS_RESULT",
        payload: result
      }).catch(() => {});
    }
  }

  // Initial check
  notifyBackground();

  // Watch for dynamic/SPA DOM mutations
  const observer = new MutationObserver(() => {
    notifyBackground();
  });

  observer.observe(document.body, { childList: true, subtree: true });
})();