// background.js — Handles URL inspection fallback (Opera-ready) and content.js messages

const tabState = new Map();

// Keyword and pattern recognition for instant address/place detection
const ADDRESS_PATTERNS = [
  /\b\d{1,4}[,\s]+(rue|avenue|ave|av|bd|boulevard|all[ée]e|chemin|impasse|place|sq|square|route|voie|quai|cours|street|st|road|rd|drive|dr|way|lane|blvd)\b/i,
  /\b(rue|avenue|bd|boulevard|chemin|place|route|street|road|st|rd)\s+[a-zà-ÿ0-9]/i,
  /\b\d{5}\b/, // Standard 5-digit postal code (FR, US ZIP)
  /\b[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}\b/i, // UK postal code
  /\b(bakery|restaurant|hotel|museum|pharmacy|station|airport|hospital|park|cinema|supermarket|bar|cafe|café|boulangerie|mus[ée]e|gare|a[ée]roport|h[ôo]pital)\b/i
];

function extractQueryAndHost(rawUrl) {
  try {
    const url = new URL(rawUrl);
    if (!url.hostname.includes("google.") || !url.pathname.includes("/search")) {
      return null;
    }
    const query = url.searchParams.get("q") || "";
    const isLocalParam = (url.searchParams.has("tbm") && url.searchParams.get("tbm") === "lcl")
                      || url.searchParams.has("rflfq");

    // Preserve valid Google host (e.g., www.google.com, www.google.co.uk, www.google.fr)
    let host = url.hostname;
    if (!host.startsWith("www.")) {
      host = "www." + host.replace(/^.*?\bgoogle\./, "google.");
    }

    return { query, isLocalParam, host };
  } catch (e) {
    return null;
  }
}

function analyzeQueryIntention(query, isLocalParam) {
  if (isLocalParam) return true;
  if (!query) return false;
  return ADDRESS_PATTERNS.some(regex => regex.test(query));
}

function updateTabIcon(tabId, isDetected, locationDetail = "") {
  const iconPath = isDetected ? "alerte.png" : "icon.png";
  const title = isDetected
    ? `GoToMaps\n${locationDetail || "Open in Google Maps"}`
    : "GoToMaps\nNo address detected";

  chrome.action.setIcon({ tabId, path: iconPath }).catch(() => {});
  chrome.action.setTitle({ tabId, title }).catch(() => {});
}

// 1. URL INSPECTION (Works out-of-the-box on Opera without manual toggles)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const targetUrl = changeInfo.url || tab.url;
  if (!targetUrl) return;

  const parsed = extractQueryAndHost(targetUrl);
  if (!parsed) {
    tabState.delete(tabId);
    updateTabIcon(tabId, false);
    return;
  }

  const detectedByUrl = analyzeQueryIntention(parsed.query, parsed.isLocalParam);

  tabState.set(tabId, {
    detected: detectedByUrl,
    target: parsed.query,
    host: parsed.host
  });

  updateTabIcon(tabId, detectedByUrl, parsed.query);
});

// 2. DOM ENRICHMENT (When content script is permitted by browser)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== "PAGE_ANALYSIS_RESULT" || !sender.tab?.id) return;

  const tabId = sender.tab.id;
  const current = tabState.get(tabId) || { host: "www.google.com" };

  if (msg.payload.detected) {
    const finalTarget = msg.payload.target || current.target;
    tabState.set(tabId, {
      detected: true,
      target: finalTarget,
      host: current.host
    });
    updateTabIcon(tabId, true, finalTarget);
  }

  sendResponse?.({ status: "acknowledged" });
});

// 3. ICON CLICK: Clean redirect to Google Maps
chrome.action.onClicked.addListener((tab) => {
  const current = tabState.get(tab.id);
  const targetQuery = current?.target || "";
  const host = current?.host || "www.google.com";

  let mapsUrl = `https://${host}/maps`;
  if (targetQuery) {
    mapsUrl = `https://${host}/maps/search/?api=1&query=${encodeURIComponent(targetQuery)}`;
  }

  chrome.tabs.create({ url: mapsUrl });
});

// Clean up state on tab close
chrome.tabs.onRemoved.addListener((tabId) => {
  tabState.delete(tabId);
});