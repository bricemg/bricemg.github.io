/**
 * YouTube SmartNav
 * - AZERTY direct access (&, é, ", ', (, -, è, _, ç, à) and standard 0-9 digits
 * - Quick zero with '²' (left of '1' on FR keyboard) mapped to '0'
 * - Instant visual HUD on the very first key pressed (e.g. "4...%" preview)
 * - Single-digit jumps to tens (e.g., 5 -> 50%) after 750ms timeout
 * - Two-digit jumps to exact percentages (e.g., 4 then 9 -> 49%)
 * - YouTube native-style HUD indicator (Percentage, Red progress bar, Timestamp)
 * - Fullscreen & SPA navigation compatible
 */

(function () {
  'use strict';

  // AZERTY key mapping without Shift (includes '²' mapped to '0')
  const AZERTY_TO_DIGIT = {
    '²': '0',
    '&': '1',
    'é': '2',
    '"': '3',
    "'": '4',
    '(': '5',
    '-': '6',
    'è': '7',
    '_': '8',
    'ç': '9',
    'à': '0'
  };

  const SINGLE_DIGIT_DELAY = 750; // Delay in ms before validating a single digit
  let digitBuffer = '';
  let digitTimeout = null;
  let hudTimeout = null;

  /**
   * Returns the active video element.
   */
  function getVideoElement() {
    return document.querySelector('video.html5-main-video') || document.querySelector('video');
  }

  /**
   * Returns the player container so HUD works seamlessly in standard and fullscreen mode.
   */
  function getPlayerContainer() {
    return (
      document.querySelector('#movie_player') ||
      document.querySelector('.html5-video-player') ||
      document.body
    );
  }

  /**
   * Creates or retrieves the YouTube-styled HUD indicator.
   */
  function getOrCreateHudIndicator() {
    let indicator = document.getElementById('percentage-position-indicator');

    if (!indicator) {
      indicator = document.createElement('div');
      indicator.id = 'percentage-position-indicator';
      indicator.style.cssText = `
        position: absolute;
        top: 15%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: rgba(0, 0, 0, 0.75);
        color: white;
        padding: 14px 22px;
        border-radius: 6px;
        z-index: 2147483647;
        font-family: 'YouTube Noto', Roboto, Arial, sans-serif;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.2s ease-in-out;
        box-shadow: 0 0 12px rgba(0, 0, 0, 0.6);
        pointer-events: none;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 8px;
        min-width: 140px;
      `;

      indicator.innerHTML = `
        <div class="percentage-value" style="
          font-size: 22px;
          font-weight: bold;
          text-align: center;
          line-height: 1;
        "></div>
        <div class="percentage-bar-container" style="
          width: 100%;
          height: 4px;
          background-color: rgba(255, 255, 255, 0.3);
          border-radius: 2px;
          overflow: hidden;
        ">
          <div class="percentage-bar-fill" style="
            height: 100%;
            background-color: #f00;
            width: 0%;
            transition: width 0.15s ease-out;
          "></div>
        </div>
        <div class="percentage-time-value" style="
          font-size: 13px;
          color: rgba(255, 255, 255, 0.85);
          text-align: center;
          font-weight: 500;
        "></div>
      `;
    }

    // Attach to player container for fullscreen support
    const container = getPlayerContainer();
    if (indicator.parentElement !== container) {
      container.appendChild(indicator);
    }

    return indicator;
  }

  /**
   * Formats seconds into MM:SS or HH:MM:SS.
   */
  function formatTime(seconds) {
    const s = Math.max(0, Math.floor(seconds));
    const hours = Math.floor(s / 3600);
    const minutes = Math.floor((s % 3600) / 60);
    const secs = s % 60;

    const pad = (num) => String(num).padStart(2, '0');

    if (hours > 0) {
      return `${hours}:${pad(minutes)}:${pad(secs)}`;
    }
    return `${minutes}:${pad(secs)}`;
  }

  /**
   * Displays the indicator with percentage (or input placeholder), progress bar and timestamp.
   */
  function showPositionIndicator(displayLabel, percentage, targetTime, duration, autoHide = true) {
    const indicator = getOrCreateHudIndicator();
    const valueEl = indicator.querySelector('.percentage-value');
    const barEl = indicator.querySelector('.percentage-bar-fill');
    const timeEl = indicator.querySelector('.percentage-time-value');

    // Update contents
    valueEl.textContent = displayLabel;
    barEl.style.width = `${percentage}%`;
    timeEl.textContent = `${formatTime(targetTime)} / ${formatTime(duration)}`;

    // Show indicator
    indicator.style.visibility = 'visible';
    indicator.style.opacity = '1';

    clearTimeout(hudTimeout);

    if (autoHide) {
      hudTimeout = setTimeout(() => {
        indicator.style.opacity = '0';
        setTimeout(() => {
          if (indicator.style.opacity === '0') {
            indicator.style.visibility = 'hidden';
          }
        }, 200);
      }, 1500);
    }
  }

  /**
   * Previews the first entered digit immediately on the HUD.
   */
  function previewSingleDigit(digit) {
    const video = getVideoElement();
    if (!video || !Number.isFinite(video.duration) || video.duration <= 0) return;

    // Estimate based on the pending tens value (e.g., 4 -> 40%, 0 -> 0%)
    const previewPercentage = parseInt(digit, 10) * 10;
    const targetTime = video.duration * (previewPercentage / 100);

    // Keep it visible without auto-hide while waiting for potential 2nd digit
    showPositionIndicator(`${digit}...%`, previewPercentage, targetTime, video.duration, false);
  }

  /**
   * Executes navigation to target percentage.
   */
  function navigateToPercentage(percentage) {
    const video = getVideoElement();
    if (!video || !Number.isFinite(video.duration) || video.duration <= 0) {
      console.warn('YouTube SmartNav: No active video found or duration unavailable.');
      return;
    }

    const clampedPercentage = Math.max(0, Math.min(99, percentage));
    const targetTime = video.duration * (clampedPercentage / 100);

    video.currentTime = targetTime;
    showPositionIndicator(`${clampedPercentage}%`, clampedPercentage, targetTime, video.duration, true);
    console.log(`YouTube SmartNav: Navigated to ${clampedPercentage}% (${formatTime(targetTime)})`);
  }

  /**
   * Checks whether the event originated from an editable field or comment section.
   */
  function isTypingContext(e) {
    const target = e.target;
    if (!target) return false;

    if (target.isContentEditable) return true;

    if (e.composedPath) {
      const path = e.composedPath();
      for (const el of path) {
        if (el instanceof Element) {
          if (el.isContentEditable) return true;
          const tag = el.tagName.toLowerCase();
          if (tag === 'input' || tag === 'textarea' || tag === 'select') return true;
        }
      }
    }

    if (typeof target.closest === 'function') {
      const match = target.closest('input, textarea, [contenteditable="true"], ytd-searchbox, #search, ytd-commentbox');
      if (match) return true;
    }

    return false;
  }

    /**
   * Normalizes keydown events to a single digit string ("0"-"9").
   * Fully compatible with AZERTY, QWERTY, QWERTZ and Numpads.
   */
  function extractDigit(e) {
    if (e.ctrlKey || e.altKey || e.metaKey) return null;

    // 1. Direct standard digits (0 to 9) - works immediately on QWERTY / QWERTZ
    if (/^[0-9]$/.test(e.key)) {
      return e.key;
    }

    // 2. AZERTY unshifted row mappings (&, é, ", ', (, -, è, _, ç, à and ²)
    if (Object.prototype.hasOwnProperty.call(AZERTY_TO_DIGIT, e.key)) {
      return AZERTY_TO_DIGIT[e.key];
    }

    // 3. Optional: treat the key to the left of "1" (` on QWERTY, ² on AZERTY) as 0
    if (e.key === '`' || e.code === 'Backquote') {
      return '0';
    }

    // 4. Physical Numpad digits (Numpad0 - Numpad9)
    if (e.code && /^Numpad[0-9]$/.test(e.code)) {
      return e.code.replace('Numpad', '');
    }

    return null;
  }

  /**
   * Handles keyboard input for navigation.
   */
  function handleKeyDown(e) {
    if (isTypingContext(e)) return;

    const digit = extractDigit(e);
    if (digit === null) return;

    e.preventDefault();
    e.stopPropagation();

    digitBuffer += digit;
    clearTimeout(digitTimeout);

    // If two digits entered, jump directly to percentage (00-99%)
    if (digitBuffer.length >= 2) {
      const percentage = parseInt(digitBuffer.slice(-2), 10);
      digitBuffer = '';
      navigateToPercentage(percentage);
      return;
    }

    // First digit pressed: show HUD instantly with "X...%"
    previewSingleDigit(digit);

    // Wait for a second digit, otherwise validate the single digit jump (750ms)
    digitTimeout = setTimeout(() => {
      if (digitBuffer.length === 1) {
        const percentage = parseInt(digitBuffer, 10) * 10;
        navigateToPercentage(percentage);
      }
      digitBuffer = '';
    }, SINGLE_DIGIT_DELAY);
  }

  /**
   * Initializes the listener.
   */
  function init() {
    window.removeEventListener('keydown', handleKeyDown, true);
    window.addEventListener('keydown', handleKeyDown, true);
    console.log('YouTube SmartNav: Extension active.');
  }

  window.addEventListener('yt-navigate-finish', init);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();