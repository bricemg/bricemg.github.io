bl_info = {
    "name": "Render ETA in Render Window",
    "author": "@BriceMG",
    "version": (1, 2, 0),
    "blender": (4, 0, 0),
    "location": "Render Window (Image Editor) > Header",
    "description": "Displays estimated remaining render time (ETA) and approximate completion time in the Render Window header for animations, follow me on Instagram & GitHub for nice stuff",
    "warning": "",
    "doc_url": "",
    "category": "Render",
}

import bpy
import time
from collections import deque
from bpy.app.handlers import persistent
from bpy.types import AddonPreferences
from bpy.props import IntProperty


# ---- Global Render Timer State ----

RENDER_TIMER_STATE = {
    "render_start_time": None,
    "last_frame_start_time": None,
    "frame_times": deque(),
    "frames_done": 0,
    "total_frames": 0,
    "is_rendering": False,
}


# ---- Add-on Preferences ----

class RENDER_OT_eta_preferences(AddonPreferences):
    bl_idname = __package__ if __package__ else __name__

    smoothing_window: IntProperty(
        name="Smoothing Window (Frames)",
        description="Number of recent frames used to calculate the rolling average render time",
        default=10,
        min=1,
        max=1000,
    )

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Render ETA - Settings", icon='TIME')
        box.prop(self, "smoothing_window")
        box.separator()
        box.label(text="Follow @BriceMG on Instagram & GitHub for nice stuff!", icon='INFO')


def get_smoothing_window() -> int:
    """Retrieves the smoothing window size from the add-on preferences."""
    addon_key = __package__ if __package__ else __name__
    try:
        addon = bpy.context.preferences.addons.get(addon_key)
        if addon is not None:
            return addon.preferences.smoothing_window
    except Exception:
        pass
    return 10  # Fallback default


# ---- Formatting & UI Utilities ----

def format_time(seconds: float) -> str:
    """Simple HH:MM:SS format (for console logs)."""
    seconds = int(max(seconds, 0))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def format_time_hms(seconds: float) -> str:
    """Readable ETA format with units: 00h:00m:00s."""
    seconds = int(max(seconds, 0))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}h:{m:02d}m:{s:02d}s"


def format_end_time_from_now(seconds: float) -> str:
    """
    Computes local clock time when rendering is expected to finish:
    now + seconds -> 'HH:MM' (24h).
    Returns an empty string if remaining seconds <= 0.
    """
    if seconds <= 0:
        return ""
    end_timestamp = time.time() + seconds
    local_t = time.localtime(end_timestamp)
    return time.strftime("%H:%M", local_t)


def find_render_area():
    """
    Finds the active IMAGE_EDITOR area showing the render result.
    Compatible across Blender 4.x and Blender 5.x.
    """
    wm = bpy.context.window_manager
    if not wm:
        return None

    for window in wm.windows:
        screen = window.screen
        if not screen:
            continue
        for area in screen.areas:
            if area.type == 'IMAGE_EDITOR':
                space = area.spaces.active
                # Verify if this area is currently displaying the render output
                if getattr(space, "show_render", False):
                    return area
                # Fallback: check if the loaded image is the Render Result
                if space and getattr(space, "image", None):
                    if space.image.type == 'RENDER_RESULT':
                        return area
    return None


def update_render_header_eta():
    """Updates the render window header text with ETA, frame progress, and end time."""
    state = RENDER_TIMER_STATE

    if not state["is_rendering"]:
        return

    area = find_render_area()
    if not area:
        return

    total = state["total_frames"]
    done = state["frames_done"]

    if total <= 0:
        return

    remaining_frames = max(total - done, 0)

    if state["frame_times"]:
        avg_time = sum(state["frame_times"]) / len(state["frame_times"])
    else:
        avg_time = 0.0

    remaining_seconds = max(remaining_frames * avg_time, 0.0)

    eta_hms = format_time_hms(remaining_seconds)
    end_time_str = format_end_time_from_now(remaining_seconds)

    if end_time_str:
        header_text = (
            f"ETA: {eta_hms} (End ~ {end_time_str}) | "
            f"Frame: {done}/{total} "
            f"(Avg: {avg_time:.2f}s)"
        )
    else:
        header_text = (
            f"ETA: {eta_hms} | "
            f"Frame: {done}/{total} "
            f"(Avg: {avg_time:.2f}s)"
        )

    area.header_text_set(header_text)
    area.tag_redraw()


def clear_render_header():
    """Restores the default header text in the render window."""
    area = find_render_area()
    if area:
        area.header_text_set(None)
        area.tag_redraw()


# ---- Render Handlers ----

@persistent
def on_render_init(*args):
    """Called when any render job starts."""
    scene = args[0] if args else bpy.context.scene
    state = RENDER_TIMER_STATE
    state["render_start_time"] = time.time()
    state["last_frame_start_time"] = None
    state["frame_times"].clear()
    state["frames_done"] = 0
    state["is_rendering"] = True

    start = scene.frame_start
    end = scene.frame_end
    step = getattr(scene, "frame_step", 1) or 1
    total = ((end - start) // step) + 1
    state["total_frames"] = max(total, 1)

    print(
        f"[Render ETA] Render started. "
        f"Total frames: {state['total_frames']} ({start} to {end}, step {step})"
    )


@persistent
def on_render_pre(*args):
    """Called before each individual frame begins rendering."""
    RENDER_TIMER_STATE["last_frame_start_time"] = time.time()


@persistent
def on_render_write(*args):
    """
    Called only when a rendered frame is written to disk (Animation render).
    Calculates moving average duration, computes ETA, and updates header.
    """
    state = RENDER_TIMER_STATE
    now = time.time()

    if state["last_frame_start_time"] is None:
        frame_time = 0.0
    else:
        frame_time = now - state["last_frame_start_time"]

    state["frames_done"] += 1

    # Apply rolling window average
    smoothing_window = get_smoothing_window()
    state["frame_times"].append(frame_time)
    while len(state["frame_times"]) > smoothing_window:
        state["frame_times"].popleft()

    # Update render window interface
    update_render_header_eta()

    # Log details to console
    avg_time = sum(state["frame_times"]) / len(state["frame_times"])
    remaining_frames = max(state["total_frames"] - state["frames_done"], 0)
    remaining_seconds = max(remaining_frames * avg_time, 0.0)

    print(
        f"[Render ETA] Frame {state['frames_done']}/{state['total_frames']} "
        f"- Time: {frame_time:.2f}s, Rolling Avg: {avg_time:.2f}s "
        f"- Remaining ETA: {format_time(remaining_seconds)}"
    )


@persistent
def on_render_complete(*args):
    """Called when the entire render job is finished."""
    state = RENDER_TIMER_STATE
    state["is_rendering"] = False

    if state["render_start_time"] is not None:
        total_time = time.time() - state["render_start_time"]
        print(f"[Render ETA] Render completed in {format_time(total_time)}.")

    clear_render_header()


@persistent
def on_render_cancel(*args):
    """Called if the render job is canceled by the user."""
    state = RENDER_TIMER_STATE
    state["is_rendering"] = False
    print("[Render ETA] Render canceled.")
    clear_render_header()


# ---- Registration ----

classes = (
    RENDER_OT_eta_preferences,
)

HANDLER_MAP = (
    ("render_init", on_render_init),
    ("render_pre", on_render_pre),
    ("render_write", on_render_write),
    ("render_complete", on_render_complete),
    ("render_cancel", on_render_cancel),
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    handlers = bpy.app.handlers
    for attr_name, func in HANDLER_MAP:
        handler_list = getattr(handlers, attr_name)
        if func not in handler_list:
            handler_list.append(func)


def unregister():
    handlers = bpy.app.handlers
    for attr_name, func in HANDLER_MAP:
        handler_list = getattr(handlers, attr_name)
        if func in handler_list:
            handler_list.remove(func)

    clear_render_header()

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()