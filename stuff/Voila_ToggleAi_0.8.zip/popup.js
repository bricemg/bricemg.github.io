document.addEventListener('DOMContentLoaded', async () => {
  const toggle = document.getElementById('toggle-ai');
  const RULE_ID = 1;

  const pureGoogleRule = {
    id: RULE_ID,
    priority: 1,
    action: {
      type: 'redirect',
      redirect: { transform: { queryTransform: { addOrReplaceParams: [{ key: 'udm', value: '14' }] } } }
    },
    condition: {
      requestDomains: ['google.com', 'google.fr', 'google.ca', 'google.be', 'google.ch'],
      urlFilter: '/search',
      resourceTypes: ['main_frame']
    }
  };

  const { withAI } = await chrome.storage.local.get('withAI');
  toggle.checked = withAI !== undefined ? withAI : true;

  toggle.addEventListener('change', async () => {
    const isWithAI = toggle.checked;
    await chrome.storage.local.set({ withAI: isWithAI });

    // Appel API unifié : le serveur (navigateur) gère la vérité absolue
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [RULE_ID],
      addRules: isWithAI ? [] : [pureGoogleRule]
    });

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (tab?.url?.includes('/search')) {
      const currentUrl = new URL(tab.url);
      
      if (isWithAI && currentUrl.searchParams.has('udm')) {
        currentUrl.searchParams.delete('udm');
      } else if (!isWithAI && !currentUrl.searchParams.has('udm')) {
        currentUrl.searchParams.set('udm', '14');
      }

      chrome.tabs.update(tab.id, { url: currentUrl.toString() });
    }
  });
});