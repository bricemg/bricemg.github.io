bl_info = {
    "name": "ViewToCam",
    "author": "@BriceMG",
    "version": (1, 3, 0),
    "blender": (4, 0, 0),
    "location": "3D Viewport > Ctrl + Alt + C",
    "description": "Create an active camera from the current viewport, follow me on Instagram & GitHub for nice stuff",
    "warning": "",
    "doc_url": "",
    "category": "Camera",
}

import bpy
import re

# Pre-compiled regex for performance on heavy scenes
CAM_NAME_REGEX = re.compile(r"^cam(\d{3})$", re.IGNORECASE)


def get_next_camera_name():
    """Returns the next sequential camera name (cam001, cam002, etc.)."""
    existing_numbers = []

    for obj in bpy.data.objects:
        if obj.type == 'CAMERA':
            match = CAM_NAME_REGEX.match(obj.name)
            if match:
                existing_numbers.append(int(match.group(1)))

    if not existing_numbers:
        return "cam001"

    next_num = max(existing_numbers) + 1
    return f"cam{next_num:03d}"


class VIEW3D_OT_copy_cam_to_view(bpy.types.Operator):
    """Duplicates the active camera, aligns it to the current 3D view, and sets it as the active render camera"""
    bl_idname = "view3d.copy_camera_to_view"
    bl_label = "Copy Active Camera to View"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        scene = context.scene
        cam_src = scene.camera

        if cam_src is None or cam_src.type != 'CAMERA':
            self.report({'ERROR'}, "No active camera found in the scene.")
            return {'CANCELLED'}

        # Safely retrieve the active 3D Viewport region data
        region_3d = context.region_data
        if not region_3d and context.space_data:
            region_3d = context.space_data.region_3d

        if not region_3d:
            self.report({'ERROR'}, "Unable to retrieve 3D Viewport data.")
            return {'CANCELLED'}

        # --- Duplicate the active camera and its data ---
        cam_copy = cam_src.copy()
        cam_copy.data = cam_src.data.copy()

        # Assign sequential name to both Object and Camera Data-block
        new_name = get_next_camera_name()
        cam_copy.name = new_name
        cam_copy.data.name = new_name

        # Clear animation data on the duplicate to prevent transform snapping
        cam_copy.animation_data_clear()
        cam_copy.data.animation_data_clear()

        # Link to active collection (fallback to scene master collection if hidden/excluded)
        target_collection = context.collection
        if not target_collection or context.layer_collection.exclude:
            target_collection = scene.collection
        target_collection.objects.link(cam_copy)

        # --- Align duplicate to the current viewport ---
        cam_copy.matrix_world = region_3d.view_matrix.inverted()

        # --- Clean selection handling (safe across all interaction modes) ---
        for obj in context.view_layer.objects:
            if obj.select_get():
                obj.select_set(False)

        cam_copy.select_set(True)
        context.view_layer.objects.active = cam_copy

        # Set as active render camera and switch viewport to camera view if you prefer, uncomment these 2 lines
        #scene.camera = cam_copy
        #region_3d.view_perspective = 'CAMERA'

        self.report({'INFO'}, f"Created ( and switched to camera ): {cam_copy.name}")

        return {'FINISHED'}


class VIEW3D_OT_copy_cam_preferences(bpy.types.AddonPreferences):
    """Fixed UI panel in the Add-on Preferences showing the shortcut"""
    # Works whether installed as a folder/zip (__package__) or run as a single .py file (__name__)
    bl_idname = __package__ if __package__ else __name__

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Shortcut (3D Viewport): Ctrl + Alt + C", icon='KEYINGSET')
        col.label(text="Follow @BriceMG on Instagram & GitHub for nice stuff!", icon='INFO')


addon_keymaps = []


def add_keymap():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="3D View", space_type='VIEW_3D')
        kmi = km.keymap_items.new(
            VIEW3D_OT_copy_cam_to_view.bl_idname,
            type='C',
            value='PRESS',
            ctrl=True,
            alt=True
        )
        addon_keymaps.append((km, kmi))


def remove_keymap():
    for km, kmi in addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_keymaps.clear()


classes = (
    VIEW3D_OT_copy_cam_to_view,
    VIEW3D_OT_copy_cam_preferences,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    add_keymap()


def unregister():
    remove_keymap()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
